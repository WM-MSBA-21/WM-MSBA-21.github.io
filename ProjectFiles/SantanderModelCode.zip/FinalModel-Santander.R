library(caret)
library(dplyr)
library(MLmetrics)
library(e1071)
set.seed(21)


rm(list=ls())

# Read in training and test data 
santander.df <- read.csv('train.csv',header=T, sep=',')

# Convert target variable to a factor 0 = No purchase; 1 = Made purchase
santander.df$target <- factor(santander.df$target)
# Drop ID_Code column
santander.df <- select(santander.df, -c('ID_code'))


# Looking at the data frame
head(santander.df)
str(santander.df$target)
table(santander.df$target)

# Split into train and test set (80/20 Split)
n <- nrow(santander.df)
train.indices <- sample(n, .8 * n)
train.data <- santander.df[train.indices,]
test.x <- santander.df[-train.indices, ]
test.y <- santander.df$target[-train.indices]


# Create train X and Y variables
train.x <- select(down_train, -c('target'))
train.y <- down_train$target


##################################################################
################## Naive Bayes ###################################
##################################################################

# Fit the Naive Bayes Model
nBayes_fit <- naiveBayes(target ~ ., data = train.data)

# Make predictions
nBayes.probs <- predict(nBayes_fit, newdata = test.x, type = 'raw') # Class probabilities
nBayes.probs <- nBayes.probs[,2] # Class probabilities for the Purchase (1) Class
nBayes.preds <- predict(nBayes_fit, newdata = test.x) # Class predicitions

#Confusion Matrix
nBayes.cMatrix <- table(nBayes.preds, test.y)
# Overall Accuracy Rate
nBayes.Acc <- Accuracy(nBayes.preds, test.y)
# ROC Area Under Curve
nBayes.AUC <- AUC(nBayes.probs, test.y)
# PRAUCfac
nBayes.PRAUC <- PRAUC(nBayes.probs, test.y)



# Cross fold validation on entire training data

# 10-fold Cross Validation
numfolds <- 10
fold.indices <- cut(1:n, breaks=numfolds, labels=F)

#Perform 10 fold cross validation
cv.rocauc <- rep(0, numfolds)

# Estimate the expected value of the true MSE
for(i in 1:numfolds){
  #Segement your data by fold using the which() function 
  test.indices <- which(fold.indices == i)
  test.data <- santander.df[test.indices, ]
  cv.train <- santander.df[-test.indices, ]
  cv.nBayes_fit <- naiveBayes(target ~ ., data = cv.train)
  cv.nBayes.probs <- predict(cv.nBayes_fit, newdata = test.data[,!(names(train.data) %in% 'target')], type = 'raw')
  cv.nBayes.probs <- cv.nBayes.probs[,2]
  cv.rocauc[i] <- AUC(cv.nBayes.probs, test.data$target)
}

sprintf('Average 10-Fold CV ROC AUC Score: %s', round(mean(cv.rocauc),4))
